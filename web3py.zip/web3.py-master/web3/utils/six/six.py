import collections

from urllib.parse import (  # noqa: F401
    urlparse,
    urlunparse,
)

Generator = collections.Generator
